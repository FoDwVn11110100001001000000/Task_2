def hello_func():
    print('Hello, it`s my first module')
