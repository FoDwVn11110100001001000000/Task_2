from setuptools import setup, find_packages

setup(
    name='clean_folder',
    version='0.0.1',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'clean_folder=clean_folder.clean:hello_func'
        ]
    },
    author='Dmytro',
    author_email='777fesenko@gmail.com',
    description='A package print text',
    classifiers='first module'
    )
